import express from 'express';
import fetch from 'node-fetch';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import path from 'path';
import { fileURLToPath } from 'url';
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const {
  SPOTIFY_CLIENT_ID,
  SPOTIFY_CLIENT_SECRET,
  SPOTIFY_REDIRECT_URI,
  APPLE_TEAM_ID,
  APPLE_KEY_ID,
  APPLE_PRIVATE_KEY
} = process.env;

if (!SPOTIFY_CLIENT_ID || !SPOTIFY_CLIENT_SECRET || !SPOTIFY_REDIRECT_URI) {
  console.warn('Warning: Missing Spotify environment variables. See .env.example');
}
if (!APPLE_TEAM_ID || !APPLE_KEY_ID || !APPLE_PRIVATE_KEY) {
  console.warn('Warning: Missing Apple Music environment variables. See .env.example');
}

const app = express();
app.use(express.static(path.join(__dirname, '..', 'public')));

// Serve frontend index
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

// Spotify: redirect user to Spotify authorize page
app.get('/api/spotify/login', (req, res) => {
  if (!SPOTIFY_CLIENT_ID || !SPOTIFY_REDIRECT_URI) {
    return res.status(500).send('Missing Spotify env vars. Check .env');
  }
  const scopes = [
    'user-read-private',
    'user-read-email',
    'playlist-read-private',
    'playlist-read-collaborative',
    'playlist-modify-public',
    'playlist-modify-private'
  ];
  const state = Math.random().toString(36).substring(2, 15);
  const authUrl =
    'https://accounts.spotify.com/authorize' +
    '?response_type=code' +
    '&client_id=' + encodeURIComponent(SPOTIFY_CLIENT_ID) +
    '&scope=' + encodeURIComponent(scopes.join(' ')) +
    '&redirect_uri=' + encodeURIComponent(SPOTIFY_REDIRECT_URI) +
    '&state=' + encodeURIComponent(state);

  res.redirect(authUrl);
});

// Spotify: callback to exchange code for tokens
app.get('/api/spotify/callback', async (req, res) => {
  const { code, error } = req.query;
  if (error) {
    return res.redirect('/?spotify_error=' + encodeURIComponent(error));
  }
  if (!code) {
    return res.redirect('/?spotify_error=missing_code');
  }
  try {
    const tokenRes = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: {
        'Authorization': 'Basic ' + Buffer.from(`${SPOTIFY_CLIENT_ID}:${SPOTIFY_CLIENT_SECRET}`).toString('base64'),
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code: code,
        redirect_uri: SPOTIFY_REDIRECT_URI
      })
    });
    const tokenData = await tokenRes.json();
    if (tokenData.error) {
      return res.redirect('/?spotify_error=' + encodeURIComponent(JSON.stringify(tokenData)));
    }
    // Redirect back to the frontend and include tokens in the fragment so the client can store them
    const fragment = [
      tokenData.access_token ? `spotify_token=${tokenData.access_token}` : '',
      tokenData.refresh_token ? `spotify_refresh=${tokenData.refresh_token}` : '',
      tokenData.expires_in ? `spotify_expires_in=${tokenData.expires_in}` : ''
    ].filter(Boolean).join('&');

    res.redirect('/#' + fragment);
  } catch (err) {
    console.error(err);
    res.redirect('/?spotify_error=server_error');
  }
});

// Apple: generate a developer token (server-side). The frontend will exchange it for a user token via MusicKit JS.
app.get('/api/apple/developer-token', (req, res) => {
  if (!APPLE_TEAM_ID || !APPLE_KEY_ID || !APPLE_PRIVATE_KEY) {
    return res.status(500).json({ error: 'Missing Apple env vars (TEAM_ID, KEY_ID, PRIVATE_KEY).' });
  }
  try {
    const now = Math.floor(Date.now() / 1000);
    const payload = {
      iss: APPLE_TEAM_ID,
      iat: now,
      exp: now + 60 * 60 * 24 * 180, // up to 6 months
      aud: 'appstoreconnect-v1'
    };
    // The private key in .env should have newlines escaped as \n; replace them back to real newlines:
    const privateKey = APPLE_PRIVATE_KEY.replace(/\\n/g, '\n');
    const token = jwt.sign(payload, privateKey, {
      algorithm: 'ES256',
      keyid: APPLE_KEY_ID
    });
    res.json({ developerToken: token });
  } catch (err) {
    console.error('Apple token error', err);
    res.status(500).json({ error: 'Failed to create developer token' });
  }
});

// basic ping
app.get('/api/ping', (req, res) => {
  res.json({ ok: true });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server listening on http://localhost:${port}`);
});