// Minimal Spotify integration (Authorization Code flow handled server-side).
// Frontend responsibilities:
// - Trigger /api/spotify/login to start auth
// - Read tokens from location.hash and store in localStorage
// - Use access token to list current user's playlists

const loginBtn = document.getElementById('spotify-login');
const statusEl = document.getElementById('spotify-status');
const playlistsEl = document.getElementById('spotify-playlists');
const playerArea = document.getElementById('spotify-player-area');
const userEl = document.getElementById('spotify-user');

loginBtn.addEventListener('click', () => {
  window.location.href = '/api/spotify/login';
});

// When Spotify server-side callback redirects back, tokens are in URL fragment (#spotify_token=...)
function readHashParams() {
  if (window.location.hash) {
    const params = new URLSearchParams(window.location.hash.substring(1));
    const token = params.get('spotify_token');
    const refresh = params.get('spotify_refresh');
    const expires = params.get('spotify_expires_in');
    if (token) {
      localStorage.setItem('spotify_token', token);
      if (refresh) localStorage.setItem('spotify_refresh', refresh);
      if (expires) localStorage.setItem('spotify_expires_in', expires);
      // remove fragment from URL
      history.replaceState(null, '', window.location.pathname + window.location.search);
      return token;
    }
  }
  return localStorage.getItem('spotify_token');
}

async function fetchJson(url, token) {
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` }});
  if (!res.ok) {
    throw new Error('API error: ' + res.status);
  }
  return res.json();
}

async function loadSpotify() {
  const token = readHashParams();
  if (!token) {
    statusEl.textContent = 'Not connected';
    return;
  }
  statusEl.textContent = 'Connected';
  playerArea.style.display = 'block';
  try {
    const me = await fetchJson('https://api.spotify.com/v1/me', token);
    userEl.textContent = me.display_name || me.id;
    // fetch playlists
    const pls = await fetchJson('https://api.spotify.com/v1/me/playlists?limit=50', token);
    playlistsEl.innerHTML = '';
    if (!pls.items || pls.items.length === 0) {
      playlistsEl.innerHTML = '<div class="small">No playlists found</div>';
      return;
    }
    pls.items.forEach(p => {
      const div = document.createElement('div');
      div.className = 'item';
      div.innerHTML = `
        <div class="cover" style="background-image:url('${p.images && p.images[0] ? p.images[0].url : ''}'); background-size:cover;"></div>
        <div class="meta">
          <div class="title">${escapeHtml(p.name)}</div>
          <div class="subtitle">${escapeHtml(p.owner.display_name || p.owner.id)} • ${p.tracks.total} tracks</div>
        </div>
        <div><button data-id="${p.id}" class="small play-pl">View</button></div>
      `;
      playlistsEl.appendChild(div);
    });
    // attach simple handler for "View" to list first 10 tracks
    playlistsEl.addEventListener('click', async (ev) => {
      if (ev.target.classList.contains('play-pl')) {
        const id = ev.target.dataset.id;
        const tracks = await fetchJson(`https://api.spotify.com/v1/playlists/${id}/tracks?limit=20`, token);
        showTracksModal(tracks.items.map(i => i.track).filter(Boolean));
      }
    });
  } catch (err) {
    console.error(err);
    statusEl.textContent = 'Error connecting';
  }
}

function showTracksModal(tracks) {
  const md = document.createElement('div');
  md.style.position = 'fixed';
  md.style.left = '50%';
  md.style.top = '50%';
  md.style.transform = 'translate(-50%,-50%)';
  md.style.background = '#0b0b0c';
  md.style.border = '1px solid rgba(255,255,255,0.04)';
  md.style.padding = '1rem';
  md.style.borderRadius = '10px';
  md.style.maxHeight = '80vh';
  md.style.overflow = 'auto';
  md.style.zIndex = 9999;
  md.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.5rem;"><strong>Tracks</strong><button id="close-modal">Close</button></div>`;
  tracks.forEach(t => {
    const el = document.createElement('div');
    el.style.display = 'flex';
    el.style.gap = '0.6rem';
    el.style.padding = '0.45rem 0';
    el.style.borderBottom = '1px solid rgba(255,255,255,0.02)';
    el.innerHTML = `
      <div style="width:44px;height:44px;background:#222;border-radius:6px;background-size:cover;background-image:url('${t.album && t.album.images && t.album.images[0] ? t.album.images[0].url : ''}')"></div>
      <div style="flex:1">
        <div style="font-weight:700">${escapeHtml(t.name)}</div>
        <div style="font-size:.9rem;color:#bdbdbd">${escapeHtml(t.artists.map(a => a.name).join(', '))}</div>
      </div>
      <div style="display:flex;align-items:center"><button class="preview-btn" data-preview="${t.preview_url}">${t.preview_url ? 'Preview' : 'No preview'}</button></div>
    `;
    md.appendChild(el);
  });
  document.body.appendChild(md);
  document.getElementById('close-modal').addEventListener('click', () => md.remove());
  md.addEventListener('click', (ev) => {
    if (ev.target.classList.contains('preview-btn')) {
      const url = ev.target.dataset.preview;
      if (!url) return alert('No preview available for this track.');
      const audio = new Audio(url);
      audio.play();
    }
  });
}

function escapeHtml(s) {
  if (!s) return '';
  return s.replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
}

// Kick off
loadSpotify();