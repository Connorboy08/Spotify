// Minimal Apple Music (MusicKit) integration.
// Flow:
// - Get developer token from /api/apple/developer-token
// - Configure MusicKit with the developer token
// - Call MusicKit.getInstance().authorize() to get user token and allow library access
// - Fetch library playlists (library.playlists()) and display them

const appleLoginBtn = document.getElementById('apple-login');
const appleStatus = document.getElementById('apple-status');
const applePlaylistsEl = document.getElementById('apple-playlists');
const applePlayerArea = document.getElementById('apple-player-area');
const appleUserEl = document.getElementById('apple-user');

// Load MusicKit JS script dynamically
function loadMusicKitScript() {
  return new Promise((resolve, reject) => {
    if (window.MusicKit) return resolve(window.MusicKit);
    const s = document.createElement('script');
    s.src = 'https://js-cdn.music.apple.com/musickit/v1/musickit.js';
    s.onload = () => resolve(window.MusicKit);
    s.onerror = reject;
    document.head.appendChild(s);
  });
}

async function initMusicKit() {
  try {
    const mk = await loadMusicKitScript();
    // fetch developer token from server
    const res = await fetch('/api/apple/developer-token');
    if (!res.ok) {
      appleStatus.textContent = 'Missing developer token (server error)';
      return;
    }
    const data = await res.json();
    const developerToken = data.developerToken;
    if (!developerToken) {
      appleStatus.textContent = 'Failed to get developer token';
      return;
    }
    // Configure MusicKit
    window.MusicKit.configure({
      developerToken: developerToken,
      app: {
        name: 'MusicBridgePlayer',
        build: '1.0.0'
      }
    });

    appleStatus.textContent = 'Ready (developer token loaded)';
    return window.MusicKit.getInstance();
  } catch (err) {
    console.error('MusicKit init error', err);
    appleStatus.textContent = 'Failed to load MusicKit';
    throw err;
  }
}

appleLoginBtn.addEventListener('click', async () => {
  try {
    const mkInstance = await initMusicKit();
    // prompt user to sign in and grant music access
    const musicUserToken = await mkInstance.authorize();
    appleStatus.textContent = 'Connected';
    applePlayerArea.style.display = 'block';
    appleUserEl.textContent = mkInstance.player?.playbackState || 'Apple Music user';
    await loadAppleLibrary(mkInstance);
  } catch (err) {
    console.error(err);
    appleStatus.textContent = 'Authorization failed';
  }
});

async function loadAppleLibrary(mk) {
  try {
    // library.playlists returns user's library playlists
    const response = await mk.api.library.playlists();
    applePlaylistsEl.innerHTML = '';
    if (!response || !response.data || response.data.length === 0) {
      applePlaylistsEl.innerHTML = '<div class="small">No library playlists found or no music subscription</div>';
      return;
    }
    response.data.forEach(pl => {
      const div = document.createElement('div');
      div.className = 'item';
      const artwork = pl.attributes && pl.attributes.artwork ? pl.attributes.artwork : null;
      const url = artwork ? artwork.url.replace('{w}', '100').replace('{h}', '100') : '';
      div.innerHTML = `
        <div class="cover" style="background-image:url('${url}'); background-size:cover;"></div>
        <div class="meta">
          <div class="title">${escapeHtml(pl.attributes?.name || 'Playlist')}</div>
          <div class="subtitle">${escapeHtml(pl.attributes?.curatorName || '')}</div>
        </div>
        <div><button data-id="${pl.id}" class="small view-apple">View</button></div>
      `;
      applePlaylistsEl.appendChild(div);
    });

    applePlaylistsEl.addEventListener('click', async (ev) => {
      if (ev.target.classList.contains('view-apple')) {
        const id = ev.target.dataset.id;
        // fetch playlist tracks
        const tracks = await mk.api.library.playlists(id + '/tracks');
        showTracksModal(tracks.data.map(t => t.attributes).filter(Boolean));
      }
    });
  } catch (err) {
    console.error('Apple library load error', err);
    applePlaylistsEl.innerHTML = '<div class="small">Error loading library</div>';
  }
}

function showTracksModal(tracks) {
  const md = document.createElement('div');
  md.style.position = 'fixed';
  md.style.left = '50%';
  md.style.top = '50%';
  md.style.transform = 'translate(-50%,-50%)';
  md.style.background = '#0b0b0c';
  md.style.border = '1px solid rgba(255,255,255,0.04)';
  md.style.padding = '1rem';
  md.style.borderRadius = '10px';
  md.style.maxHeight = '80vh';
  md.style.overflow = 'auto';
  md.style.zIndex = 9999;
  md.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.5rem;"><strong>Tracks</strong><button id="close-modal-apple">Close</button></div>`;
  tracks.forEach(t => {
    const el = document.createElement('div');
    el.style.display = 'flex';
    el.style.gap = '0.6rem';
    el.style.padding = '0.45rem 0';
    el.style.borderBottom = '1px solid rgba(255,255,255,0.02)';
    el.innerHTML = `
      <div style="width:44px;height:44px;background:#222;border-radius:6px;background-size:cover;background-image:url('${t.artwork ? t.artwork.url.replace('{w}','100').replace('{h}','100') : ''}')"></div>
      <div style="flex:1">
        <div style="font-weight:700">${escapeHtml(t.name)}</div>
        <div style="font-size:.9rem;color:#bdbdbd">${escapeHtml((t.artistName || '') )}</div>
      </div>
      <div style="display:flex;align-items:center"><button class="play-apple" data-preview="${t.previews && t.previews[0] ? t.previews[0].url : ''}">${t.previews && t.previews[0] ? 'Preview' : 'No preview'}</button></div>
    `;
    md.appendChild(el);
  });
  document.body.appendChild(md);
  document.getElementById('close-modal-apple').addEventListener('click', () => md.remove());
  md.addEventListener('click', (ev) => {
    if (ev.target.classList.contains('play-apple')) {
      const url = ev.target.dataset.preview;
      if (!url) return alert('No preview available for this track.');
      const audio = new Audio(url);
      audio.play();
    }
  });
}

function escapeHtml(s) {
  if (!s) return '';
  return s.replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
}