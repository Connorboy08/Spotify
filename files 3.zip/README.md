# Music Bridge Player (Starter)

This is a starter demo app showing a combined Spotify-style and Apple Music-style UI and the minimum server endpoints needed to sign users in and fetch playlists.

IMPORTANT: This is a demo / starter only. Production apps should:
- Use secure session management and CSRF protection.
- Store tokens securely on the server (or use refresh flows properly).
- Handle token refresh for Spotify.
- Follow each service's terms.

Requirements
- Node 18+ (or Node 16+)
- A Spotify App (Client ID & Client Secret). Set Redirect URI to:
  `http://localhost:3000/api/spotify/callback`
- An Apple Music Private Key (.p8) from your Apple Developer account (with Key ID and Team ID).

Environment variables
Create a `.env` file at the project root with the values from `.env.example`. For the Apple private key, you can paste the .p8 contents into the env var but you must escape newlines as `\n`. Example:

APPLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\nMIGT...rest of key...\n-----END PRIVATE KEY-----"

Install & run
1. npm install
2. npm start
3. Open http://localhost:3000

What it does
- Spotify:
  - Clicking "Login with Spotify" redirects you to Spotify to authorize.
  - After authorizing, the server exchanges the code for tokens and returns an access token in the URL fragment; the frontend stores it and lists your playlists (and shows previews when available).
- Apple Music:
  - Clicking "Login with Apple Music" asks the server for a developer token, initializes MusicKit, and calls `MusicKit.authorize()` to obtain a music user token in the browser. The frontend then lists library playlists and previews.

Notes & next steps you might want
- Persist tokens server-side and implement refresh token handling for Spotify.
- Harden server endpoints and add sessions/cookies.
- Improve UI and add full player controls (seek, queue, volume) using Spotify Web Playback SDK and MusicKit player APIs.
- Add error handling and better UI/UX for mobile.

If you want, I can:
- Convert Spotify flow to PKCE (no client secret required on server for public clients).
- Add server-side token storage and refresh handling for Spotify.
- Implement Spotify Web Playback SDK to actually stream music via a web player (requires user to have Spotify Premium).
- Add real Apple Music playback controls using MusicKit player APIs.

Tell me which of the above you'd like next and I’ll implement it.